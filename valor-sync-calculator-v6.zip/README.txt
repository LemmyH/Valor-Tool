Valor Sync Calculator
=====================
Mobile-first PWA prototype for Valor Reforged.

Files:
- index.html
- manifest.json
- service-worker.js

Usage:
1. Put these files on any HTTPS static host.
2. Open index.html on your phone.
3. Use browser menu -> Add to Home Screen.

Movement data was derived from user-provided in-game measurements:
Scouts 40, Knights 60, Guardians 70, Berserkers 110, Lancers 120,
Sentries 130, Rams 200, Ballistas 200, Scholars 250 seconds/tile.

Distance: sqrt(dx^2 + dy^2).
The app currently calculates from those measured values and uses the phone's local time.
